import { Component } from '@angular/core';

@Component({
  selector: 'pro-result-fail',
  templateUrl: './fail.component.html',
})
export class ProResultFailComponent {}
