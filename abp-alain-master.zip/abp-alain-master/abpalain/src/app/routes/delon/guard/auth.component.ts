import { Component } from '@angular/core';

@Component({
  selector: 'app-guard-auth',
  template: `
    <p>这是一个user1页面</p>
  `,
})
export class GuardAuthComponent {}
