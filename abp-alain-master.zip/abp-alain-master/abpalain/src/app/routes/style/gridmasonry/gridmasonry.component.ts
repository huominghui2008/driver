import { Component } from '@angular/core';

@Component({
  selector: 'app-gridmasonry',
  templateUrl: './gridmasonry.component.html',
})
export class GridMasonryComponent {}
