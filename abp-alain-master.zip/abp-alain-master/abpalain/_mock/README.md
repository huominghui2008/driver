[Document](http://ng-alain.com/docs/mock)
