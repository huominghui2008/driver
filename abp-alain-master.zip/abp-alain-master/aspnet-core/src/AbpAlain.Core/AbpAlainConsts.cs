﻿namespace AbpAlain
{
    public class AbpAlainConsts
    {
        public const string LocalizationSourceName = "AbpAlain";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
