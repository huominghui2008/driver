﻿using Abp.MultiTenancy;
using AbpAlain.Authorization.Users;

namespace AbpAlain.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
